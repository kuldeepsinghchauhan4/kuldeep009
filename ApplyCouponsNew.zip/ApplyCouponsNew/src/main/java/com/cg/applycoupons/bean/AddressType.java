package com.cg.applycoupons.bean;

public enum AddressType 
{
	HOME,WORK
}
