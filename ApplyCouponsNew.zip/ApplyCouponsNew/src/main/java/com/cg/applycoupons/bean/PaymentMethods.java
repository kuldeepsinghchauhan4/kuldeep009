package com.cg.applycoupons.bean;
public enum PaymentMethods 
{
	CASH_ON_DELIVERY , NETBANKING , CARD;
}
