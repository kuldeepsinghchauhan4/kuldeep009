package com.cg.applycoupons.exceptions;

public class InvalidProductId extends RuntimeException{
	public InvalidProductId(String message) {
		super(message);
		
	}
}
