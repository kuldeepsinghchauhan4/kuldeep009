package com.capgemini.capstore.beans;

public enum MerchantType
{
	NORMAL,THIRD_PARTY;
}
