package com.capgemini.capstore.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.capgemini.capstore.service.ICouponService;


@Controller
public class CouponController {

	@Autowired
	ICouponService service;

	
	 


	public ICouponService getService() {
		return service;
	}





	public void setService(ICouponService service) {
		this.service = service;
	}





	@RequestMapping(value = "/applyCoupons", method = RequestMethod.POST)
	public double applyCoupons(String couponCode, double price)  {

		return service.applyCoupons(couponCode, price);

	}

} 