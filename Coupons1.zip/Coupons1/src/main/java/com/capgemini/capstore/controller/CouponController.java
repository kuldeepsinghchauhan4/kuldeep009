package com.capgemini.capstore.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.capstore.service.ICouponService;


@Controller
public class CouponController {

	@Autowired
	ICouponService service;

	
	 


	public ICouponService getService() {
		return service;
	}





	public void setService(ICouponService service) {
		this.service = service;
	}





	@RequestMapping(value = "/applyCoupons", method = RequestMethod.GET)
	public String applyCoupons(@RequestParam("couponCode")String couponCode, @RequestParam("price")double price,Model model)  {
		
		System.out.println("=====================================================================");
		System.out.println("coupon code"+couponCode);
		System.out.println("price"+price);
		double updatedPrice= service.applyCoupons(couponCode, price);
		System.err.println(updatedPrice);
		
		model.addAttribute("price", updatedPrice);
		return "returnPage.jsp";

	}

} 