package com.capgemini.capstore.dao;

import java.util.Date;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Orders;



@Transactional
@Repository("repo")
public class ICouponDaoImpl implements ICouponDao{

	@PersistenceContext
	EntityManager entityManager;


 public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
public double applyCoupons(String couponCode, double price) {
		
		double totalprice = 0;
		Coupon c1=new Coupon();
		String cou= c1.getCoupon_code();
		Date enddate=c1.getExpiry_date();
	Orders o1=new Orders();
		double subo1=o1.getSubTotal();
		String description=(String) entityManager.createQuery("select coupon.description from Coupon coupon where coupon.couponCode=:couponCode").setParameter("couponCode", couponCode).getSingleResult();
      
	/*
		     if(today.compareTo(enddate) <0){// not expired
                 return false;*/
		if(c1.isCoupon_applied()==false) {
			return subo1;
			
		}
		else
		{
			
		if(subo1>1000) 
		{
		double str=Double.parseDouble(c1.getDescription());
			 totalprice=subo1-((subo1*str)/100);
			
		}
		else if(subo1>5000) 
		{
		double str=Double.parseDouble(c1.getDescription());
			 totalprice=subo1-((subo1*str)/100);
			
		}
		else 
		{
		double str=Double.parseDouble(c1.getDescription());
			 totalprice=subo1-((subo1*str)/100);
			
		}
		return totalprice;
		
	}
	}

}
