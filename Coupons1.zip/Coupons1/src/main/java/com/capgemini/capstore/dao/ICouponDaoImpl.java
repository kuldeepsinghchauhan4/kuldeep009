package com.capgemini.capstore.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.util.SocketUtils;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Orders;



@Transactional
@Repository("repo")
public class ICouponDaoImpl implements ICouponDao{

	@PersistenceContext
	EntityManager entityManager;


 public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
public double applyCoupons(String couponCode, double price) 
	{
		System.out.println(couponCode+","+price);
		double totalprice = 0;
	/*	Coupon c1=new Coupon();
		String couponvalue=c1.getDescription();*/
		
		/*Coupon c1=new Coupon();
		String cou= c1.getCoupon_code();
		Date enddate=c1.getExpiry_date();
		System.out.println(c1);*/
		/*LocalDate today=LocalDate.now();
		Instant instant=Instant.ofEpochMilli(c1.getExpiry_date().getTime());
		LocalDateTime localdatetime=LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
		LocalDate couponLocalDate=localdatetime.toLocalDate();
		if(couponLocalDate.compareTo(today)>=0) {*/
		/*	Orders o1=new Orders();
			double subo1=o1.getSubTotal();*/
			
		
		//System.out.println("Enter ssssssssssssssss");
		
		
		//String stringDate=entityManager.createQuery("select c.expiry_date from Coupon c where c.coupon_code =:couponCode").setParameter("couponCode", couponCode).getSingleResult().toString();
		
	/*	
		System.out.println(stringDate);
	
		try {
			Date date = new SimpleDateFormat("yyyy-mm-dd").parse(stringDate);
			System.out.println(date);
			date.compareTo(LocalDate.now());
				
			} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(enddate); 
		*/
	/*	
		String description=(String) entityManager.createQuery("select coupon.description from Coupon coupon where coupon.coupon_code=:couponCode").setParameter("couponCode", couponCode).getSingleResult();
		//Boolean couponapplied=(Boolean) entityManager.createQuery("select coupon.coupon_applied from Coupon coupon where coupon.coupon_code=:couponCode").setParameter("couponCode", couponCode).getSingleResult();
	//	System.out.println("coupon values:"+enddate);
		System.out.println("coupon values:"+description);*/
		Coupon coupon=(Coupon) entityManager.createQuery("select p from Coupon p where p.coupon_code=:couponCode").setParameter("couponCode", couponCode).getSingleResult();
		System.out.println(coupon.getCoupon_id());
		Double description=Double.parseDouble(coupon.getDescription());
		if(price>1000)
		{
			totalprice=price-((price*description)/100);
		}
		else
		{
			totalprice=price;
		}
		
		
		System.out.println(totalprice);
	
		return totalprice;	
	}
}
		
		
		
	