package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.dao.ICouponDao;


@Service("service")
public class ICouponSerImpl implements ICouponService {


	@Autowired
	public ICouponDao returnDao;
	
	public ICouponDao getReturnDao() {
		return returnDao;
	}

	public void setReturnDao(ICouponDao returnDao) {
		this.returnDao = returnDao;
	}

	@Override
	public double applyCoupons(String couponCode,double price) 
	{  
		return returnDao.applyCoupons(couponCode, price);

}
}


	
