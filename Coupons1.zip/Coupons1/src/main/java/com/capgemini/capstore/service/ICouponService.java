package com.capgemini.capstore.service;

public interface ICouponService {

	public double applyCoupons(String couponCode, double price) ;

}
